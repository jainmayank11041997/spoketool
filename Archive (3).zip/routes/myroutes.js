
const { descriptionToolEntry } = require('../controllers/SpokeDescriptionToolEntry');
const { xmlGenerator } = require('../controllers/SpokeDescriptionToolUtils');
const { successHandler } = require('../controllers/SpokeDescriptionToolUtils');
const { readFiles } = require('../controllers/UploadAndReadFiles');
const { SpokeCleanupEntry } = require('../controllers/SpokeCleanUpTool');
const { selectAction } = require('../controllers/SpokeDescriptionToolEntry');
const { downloadZip } = require('../controllers/DynamicChoiceRemoverTool');
const { DynamicChoiceRemoverEntry } = require('../controllers/DynamicChoiceRemoverTool')
const { home } = require('../controllers/DynamicChoiceRemoverTool');
const {pluginConverterToolEntry} = require('../controllers/PluginConverterTool');
const {addToStats} = require('../controllers/PluginConverterTool');
const {renderAnalytics}= require('../controllers/Analytics.js');
var multer = require('multer');
var upload = multer();
const path = require('path');
const {renderSpokes} = require('../controllers/Analytics');
export const routes = (app) => {
    app.get('/submit', (req, res) => {

        console.log('params us ' + JSON.stringify(req.query));
        descriptionToolEntry(req, res, req.query.actionName);
    });
    app.post('/generate_xml', (req, res) => {
        xmlGenerator(req, res, app);
    }
    );
    app.post('/success', (req, res) => {
        successHandler(req, res);
    }
    );
    app.get('/success', (req, res) => {
        successHandler(req, res);
    }
    );
    app.post('/select_action', (req, res) => {
        readFiles(req, res);
    }
    );
    app.get('/eliminate_co', (req, res) => {
        eliminateCo(req, res);
    }
    );
    app.get('/analytics', (req, res) => {
        renderAnalytics(req, res);
    }
    );
    app.get('/spokes_served', (req, res) => {
        renderSpokes(req, res);
    }
    );
    app.get('/purpose', (req, res) => {
        var path = require('path');
        var appDir = path.dirname(require.main.filename);
        var view_path = appDir + '/views/';
        res.sendFile(view_path + "select.html")
    }
    );
    app.post('/pickTool', (req, res) => {
        if (req.body.purpose == "wd")
            selectAction(req, res);
        else if (req.body.purpose == "eco")
            SpokeCleanupEntry(req, res);
        else if(req.body.purpose == "pct")
        {
            res.sendFile(path.join(__dirname, '../public/converterIndex.html'));
        }
        else
            DynamicChoiceRemoverEntry(req, res);
    }
    );
    app.get('/pickTool', (req, res) => {
        var path = require('path');
        var appDir = path.dirname(require.main.filename);
        var view_path = appDir + '/views/';
        res.sendFile(view_path + "select.html")
    }
    );
    app.post('/downloadZip', (req, res) => {
        downloadZip(req, res);
    });
    app.post('/home', (req, res) => {
        home(req, res);
    });
    app.post('/upload',upload.fields([]),(req,res) => {
        pluginConverterToolEntry(req,res);
    })
}
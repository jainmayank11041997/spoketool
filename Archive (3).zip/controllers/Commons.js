//Common functions in all tools
const fs = require('fs');
const path = require('path');

export const getAttributeFromAttrubutesString = (str, value) => {
    str = str.toString();
    var nameValues = str.split(',');
    for (var i in nameValues) {
        if (nameValues[i].split('=')[0] == value) {
            return nameValues[i].split('=')[1];
        }
    }
    return "";
}

export const AddToUsageStatistics = (spokeName, tool) => {
    const usageFile = JSON.parse(fs.readFileSync(path.join(__dirname,'../usage-statistics.json')));
    var stats = usageFile["Spoke Details"];
    var stat = {};
    stat["Spoke Name"] = spokeName;
    stat["Tool"] = tool;
    var isSpokeAlreadyUsed = false;
    for (var i =0 ;i<stats.length;i++)
    {
        if(spokeName && spokeName != "" && stats[i]["Spoke Name"] == spokeName)
        {
            if(!stats[i]["Tools"].includes(tool))
            stats[i]["Tools"].push(tool);
            isSpokeAlreadyUsed = true;
            break;
        } 
    }
   if(!isSpokeAlreadyUsed)
   {
       stat = {};
       if(spokeName)
       {
       stat["Spoke Name"] = spokeName;
       stat["Tools"] = [];
       stat["Tools"].push(tool);
       stats.push(stat);
       }
   }
   if(spokeName)
   usageFile["Spoke Details"] = stats;
   fs.writeFileSync(path.join(__dirname,'../usage-statistics.json'),JSON.stringify(usageFile));
}

export const addToToolStats = (tool) =>
{
    const usageFile = JSON.parse(fs.readFileSync(path.join(__dirname,'../usage-statistics.json')));
    var toolStats = usageFile["Tool Stats"];
    for (var i =0 ;i<toolStats.length;i++)
    {
        if(toolStats[i]["Tool Name"] == tool)
        {
           toolStats[i].Hits++;
           break;
        } 
    }
    usageFile["Tool Stats"] = toolStats;
    fs.writeFileSync(path.join(__dirname,'../usage-statistics.json'),JSON.stringify(usageFile));
} 
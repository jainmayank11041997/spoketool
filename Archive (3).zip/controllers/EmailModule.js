var nodemailer = require('nodemailer');
const path = require('path');
var transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'ihubspoketools@gmail.com',
    pass: 'dev@ihub'
  }
});

const {scheduleJob} =require('node-schedule');

var mailOptions = {
    from: 'veenamkarthik@gmail.com',
    to: 'kalyanveenam@gmail.com',
    subject: 'Sending Email using Node.js',
    text: 'That was easy!'
  };

export const sendEmail = (to,subject,text,attachmentPath) =>
{


    mailOptions.to = to;
    mailOptions.subject = subject;
    mailOptions.text = text;
    if(attachmentPath)
    {
        mailOptions.attachments = [];
        var attachment = {};
        attachment.path = attachmentPath;
        mailOptions.attachments.push(attachment)
    }
    transporter.sendMail(mailOptions, function(error, info){
        if (error) {
          console.log(error);
        } else {
          console.log('Email sent: ' + info.response);
        }
      });
}

export const emailScheduler = scheduleJob('* /1 * * * *', function(){

 });
 

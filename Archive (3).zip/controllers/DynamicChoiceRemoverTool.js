const {addToToolStats} = require('./Commons');
const {AddToUsageStatistics} = require('./Commons');
var fs = require('fs');
var path = require("path");
var xml2jsConverter = require('xml2js').parseString;
var xml2js = require('xml2js');
var xmlBuilder = new xml2js.Builder();
var Busboy = require('busboy');
var archiver = require('archiver');

const deleteFile = () => {
    const zipPath = __dirname + '../update.zip';
    fs.access(zipPath, fs.F_OK, (err) => {
        if (!err) {
            console.log("deleting the update.zip folder now from server!!");
            fs.unlinkSync(zipPath);
        }
    });
};

export const downloadZip = (req, res) => {
    const zipPath = __dirname + '/../update.zip';
    fs.access(zipPath, fs.F_OK, (err) => {
        if (!err) {
            console.log("downloading the update.zip folder from server!!");
            res.download(zipPath, "update.zip");
            deleteFile();
        } else {
            var view_path = appDir + '/views/';
            res.sendFile(view_path + "nothingToDownload.html");
        }
    });
}

export const DynamicChoiceRemoverEntry = (req, res) => {
    var spoke_name;
    try
    {
    xml2js.parseString(global.typeDefFiles[Object.keys(global.typeDefFiles)[0]], function (err, result) {
        if (result) {
            spoke_name = result.record_update.sys_hub_action_type_definition[0].sys_package[0].$.display_value.replace("Spoke", "").trim();
            addToToolStats("Dynamic Choice Remover Tool");
            AddToUsageStatistics(spoke_name,"Dynamic Choice Remover Tool");
        }
        else
        {
            console.log('err '+err);
        }
    });
    }
    catch(e)
    {
        console.log('Cannot read spoke name '+e.message);
    }
    global.dynamicChoicesRemovedFromFiles = [];
    var busboy = new Busboy({
        headers: req.headers
    });
    var newXMLFile;
    var outputFilePath = __dirname + '/../update.zip';
    var output = fs.createWriteStream(outputFilePath);
    console.log("created file");
    var archive = archiver('zip', {
        zlib: { level: 9 } // Sets the compression level.
    });
    var actionDefinitionFiles = {};
    var archive = archiver('zip', {
        zlib: { level: 9 } // Sets the compression level.
    });
    Object.keys(typeDefFiles).forEach((key, index) => {
        xml2jsConverter(typeDefFiles[key], function (err, result) {
            newXMLFile = removeDynamicChoicesFromFile(result);
        })
        if (newXMLFile) {
            archive.append(newXMLFile, { name: key });
        } else {
            archive.append(typeDefFiles[key], { name: key });
        }
    })
    Object.keys(otherFiles).forEach((key, index) => {
        archive.append(otherFiles[key], { name: key });
    })
    archive.pipe(output);
    archive.finalize();
    output.on('close', function () {
        console.log("so deleted choices are ==> " + JSON.stringify(dynamicChoicesRemovedFromFiles));
        if (dynamicChoicesRemovedFromFiles && dynamicChoicesRemovedFromFiles.length > 0) {
            res.render('showRemovedChoicesAndActions', { dynamicChoicesRemovedFromFiles: dynamicChoicesRemovedFromFiles });
        } else {
            res.sendFile(path.join(__dirname, '../views', 'noChoices.html'));
        }

    });
};

function removeDynamicChoicesFromFile(result) {

    var sysIdsOfDynamicChoices = [];
    var dynamicChoicesInternalNames = [];
    var dynamicChoicesLabels = {};
    var fileName = "", fileLabel = "";
    /* Fetching sys_id of all the dynamic inputs */

    if (result.record_update.sys_hub_action_input_action_instance) {
        result.record_update.sys_hub_action_input_action_instance.map(function (element) {
            if (element.action_input) {
                element.action_input.map(function (elementIn) {
                    if ((elementIn._) && !(sysIdsOfDynamicChoices.indexOf(elementIn._)> -1)) {
                        sysIdsOfDynamicChoices.push(elementIn._);
                    }
                });
            }
        });
    }

    /* Fetching sys_id of all the dynamic inputs completed */


    /* Fetching names of all the dynamic inputs from their sys_id  */

    if (sysIdsOfDynamicChoices.length > 0) {
        sysIdsOfDynamicChoices.map(function (sysIdOfDynamicChoice) {
            if (result.record_update.sys_hub_action_input) {
                result.record_update.sys_hub_action_input.map(function (action_inputs) {
                    if ((action_inputs.element) && ((action_inputs.sys_id) == sysIdOfDynamicChoice) && !(dynamicChoicesInternalNames.indexOf((
                        action_inputs.element).toString()) > -1)) {
                        console.log('dasd ' + action_inputs.element);
                        dynamicChoicesInternalNames.push(action_inputs.element);
                        dynamicChoicesLabels[action_inputs.element] = (action_inputs.label).toString();
                    }
                });
            }
        });
    } else {
        console.log("There are no dynamic inputs for this action!!");
    }

    /* Fetching names of all the dynamic inputs from their sys_id completed */


    /* Removing the dynamic sys_choice */
    if (dynamicChoicesInternalNames && dynamicChoicesInternalNames.length > 0) {
        var choices = [];
        for (var dynamicChoiceInternalName in dynamicChoicesInternalNames) {
            if (result && result.record_update) {
                if (result.record_update.sys_choice) {
                    (result.record_update.sys_choice).map(function (element, index) {
                        if (element.$.field)
                            console.log('a = ' + element.$.field + " b = " + dynamicChoicesInternalNames[dynamicChoiceInternalName])
                        if ((element.$.field) && (((element.$.field).toLowerCase()) == dynamicChoicesInternalNames[dynamicChoiceInternalName])) {
                            fileLabel = (result.record_update.sys_hub_action_type_definition[0].sys_name).toString();
                            fileName = (result.record_update.sys_hub_action_type_definition[0].internal_name).toString();
                            if (!(choices.indexOf(dynamicChoicesLabels[dynamicChoicesInternalNames[dynamicChoiceInternalName]]) > -1)) {
                                choices.push(dynamicChoicesLabels[dynamicChoicesInternalNames[dynamicChoiceInternalName]]);
                            }
                            console.log("deleting ==> " + dynamicChoicesInternalNames[dynamicChoiceInternalName] + " , " + (element.$.field).toLowerCase() + " , index ==> " + index);
                            (result.record_update.sys_choice).splice(index, 1);
                        } else { }
                    });
                }
            }
        }

        if ((choices.length > 0) && !(dynamicChoicesRemovedFromFiles.some(dynamicChoiceRemovedFromFile => ((dynamicChoiceRemovedFromFile.actionName == fileName) && (dynamicChoiceRemovedFromFile.actionLabel == fileLabel))))) {
            dynamicChoicesRemovedFromFiles.push({
                actionLabel: fileLabel,
                actionName: fileName,
                choiceName: choices
            });
        }

        return (xmlBuilder.buildObject(result));
    } else {
        return null;
    }
}
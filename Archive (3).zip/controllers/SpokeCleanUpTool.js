//Entry point and the utils for the Spoke Clean Up Tool
const { getAttributeFromAttrubutesString } = require('./Commons');
const{AddToUsageStatistics} = require('./Commons');
const{addToToolStats} = require('./Commons');
export const SpokeCleanupEntry = (req, res) => {
    addToToolStats("Clean Up Tool");
    AddToUsageStatistics(global.spokeName,"Clean Up Tool");
    var fs = require('fs');
    var filesNeeded = [];
    var xmlParser = require('xml2js');
    var coMap = {};
    for (var j = 0; j < Object.keys(typeDefFiles).length; j++) { // reading each type def file
        try {
            xmlParser.parseString(typeDefFiles[Object.keys(typeDefFiles)[j]], function (err, result) { // converting each file to JSON
                if (result.record_update) {
                    if (result.record_update.sys_hub_action_input) { // inputs
                        for (var i = 1; i < result.record_update.sys_hub_action_input.length; i++) {
                            if (!result.record_update.sys_hub_action_input[i].label)
                                continue;
                            var input = {};
                            var attributes = result.record_update.sys_hub_action_input[i].attributes;
                            input.coID = getAttributeFromAttrubutesString(attributes, "co_type_name"); //fetches the co ID 
                            coMap[input.coID] = "";
                        }
                    }
                    if (result.record_update.sys_hub_action_output) { //outputs
                        for (var i = 1; i < result.record_update.sys_hub_action_output.length; i++) {
                            if (!result.record_update.sys_hub_action_output[i].label)
                                continue;
                            var output = {};
                            var attributes = result.record_update.sys_hub_action_output[i].attributes;
                            output.coID = getAttributeFromAttrubutesString(attributes, "co_type_name");
                            coMap[output.coID] = "";
                        }
                    }
                    if (result.record_update.sys_hub_step_ext_output) { //step outputs
                        for (var i = 1; i < result.record_update.sys_hub_step_ext_output.length; i++) {
                            if (!result.record_update.sys_hub_step_ext_output[i].label)
                                continue;
                            var output = {};
                            var attributes = result.record_update.sys_hub_step_ext_output[i].attributes;
                            output.coID = getAttributeFromAttrubutesString(attributes, "co_type_name");
                            coMap[output.coID] = "";
                        }
                    }
                    if (result.record_update.sys_hub_step_ext_input) { // step inputs
                        for (var i = 1; i < result.record_update.sys_hub_step_ext_input.length; i++) {
                            if (!result.record_update.sys_hub_step_ext_input[i].label)
                                continue;
                            var output = {};
                            var attributes = result.record_update.sys_hub_step_ext_input[i].attributes;
                            output.coID = getAttributeFromAttrubutesString(attributes, "co_type_name");
                            coMap[output.coID] = "";
                        }
                    }
                }
            });
        }
        catch (e) {
            console.log(e);
        }
    }
   for (var j = 0; j < Object.keys(flowFiles).length; j++) { // reading each flow file
        try {
            xmlParser.parseString(flowFiles[Object.keys(flowFiles)[j]], function (err, result) { // converting each file to JSON
                if (result.record_update) {
                    if (result.record_update.sys_hub_flow_input) { // inputs
                        console.log('Flows has inputs')
                        for (var i = 1; i < result.record_update.sys_hub_flow_input.length; i++) {
                            if (!result.record_update.sys_hub_flow_input[i].label)
                                continue;
                            var input = {};
                            var attributes = result.record_update.sys_hub_flow_input[i].attributes;
                            input.coID = getAttributeFromAttrubutesString(attributes, "co_type_name"); //fetches the co ID 
                            coMap[input.coID] = "";
                        }
                    }
                }
            });
        }
        catch (e) {
            console.log(e);
        }
    }
    /*
    coMap stores the coIDs of all complex objects in inputs,outputs, step inputs, step outputs, it takes the below JSON Structure
    {
        "COID":"",
        "COID2":""
    }
    */

    for (var j = 0; j < Object.keys(coMap).length; j++) {
        filesNeeded.push(getFileNameFromCoID(Object.keys(coMap)[j]) + ".xml"); // Get the files which has the coID and add them to needed files array.
        console.log(JSON.stringify(filesNeeded));
    }
    
    console.log('all files are ' + JSON.stringify(filesNeeded));
    var junkFiles = getJunkFiles(filesNeeded);
    var script = "";
    for (var i = 0; i < junkFiles.length; i++) {
        script += "\n rm " + junkFiles[i];
    }
    try {
        var writeStream = fs.createWriteStream("./files/script.sh");
        writeStream.write(script, (err) => {
            if (err) {
            }
            else {
                res.download("./files/script.sh", "script.sh", function (err) {
                    if (err) {
                    }
                    else
                        fs.unlink("./files/script.sh", function (err) { });
                });
            }
        });
        writeStream.end();
    }
    catch (e) {
        console.log('IO Exception');
    }
}

const getJunkFiles = (filesNeeded) => { // Removing needed files from all files will give us the junk files
    var filenames = Object.keys(global.coFiles);
    var junkFiles = [];
    for (var i in filenames) {
        if (!filesNeeded.includes(filenames[i]))
            junkFiles.push(filenames[i]);
    }
    return junkFiles;
}

const getFileNameFromCoID = (coID) => { // Searches all coFiles with each coID and returns the filename if present
    var xmlParser = require('xml2js');
    var coKeys = Object.keys(coFiles);
    var diction = {};
    diction.found = false;
    for (var i = 0; i < coKeys.length; i++) {

        xmlParser.parseString(global.coFiles[coKeys[i]], function (err, result) {
            if (result) {
                if (result.record_update && result.record_update.sys_complex_object) {
                    var contentString = result.record_update.sys_complex_object[0].serialized_content;
                    var unEscaped = unescape(unescape(unescape(contentString)));
                    try {
                        var json = JSON.parse(unEscaped);
                    }
                    catch (e) {
                        console.log('Invalid json ' + coKeys[i] + " " + e);
                    }
                    var complexObjectId = Object.keys(json)[0];
                    var filename = 'sys_complex_object_' + result.record_update.sys_complex_object[0].sys_id[0];
                    complexObjectId = complexObjectId.substring(complexObjectId.indexOf(":") + 1);
                    if (coID == 'FDc5531e48975bc450d94825176274466c')
                        console.log(complexObjectId);
                    if (complexObjectId == coID) {
                        console.log('comparing yoo');
                        diction.found = true;
                        diction.filename = filename;
                    }
                }
            }
            else {
                console.log('no ' + err);
            }

        });

    }
    if (diction.found == true) {
        return diction.filename;
    }
    else
        return coID;
}
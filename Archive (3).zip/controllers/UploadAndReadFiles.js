/*Responsible for uploading the files and reading them
The files after scanned are store in global so that they will be accesible in all controller
The format of files are as follows
{
    "filename":"content",
    "filename":"content"
}
Complex Object files are stored in coFiles and Type definition files are stored in typeDefFiles. These can be accessible in any controller without the need of importing anything

The whole directory is uploaded under /uploadDir in the server
*/
const fs = require('fs');
const path = require('path');
const fse = require('fs-extra');
const xmlParser = require('xml2js');
export const readFiles = (req, res) => {
    var Busboy = require('busboy');
    var busboy = new Busboy({ headers: req.headers });
    global.typeDefFiles = {};
    global.coFiles = {};
    global.actionMap = {};
    global.otherFiles = {};
    global.flowFiles = {};
    var filePaths = [];
    var i = 0;
    fse.emptyDirSync(path.join(__dirname, '../uploadDir'));
    busboy.on('field', async function (fieldname, val) {
        if (fieldname == 'filePath')
            filePaths.push(val);
    });
    busboy.on('file', function (fieldname, file, filename, encoding, mimetype) {
        var dir = path.join(__dirname, '../uploadDir', path.dirname(filePaths[i]));
        var saveTo = path.join(__dirname, '../uploadDir', filePaths[i]);
        try {
            if (!fs.existsSync(dir))
                fs.mkdirSync(dir);
        }
        catch (e) {
        }
        try {
            if (fs.existsSync(path.dirname(saveTo)))
                file.pipe(fs.createWriteStream(saveTo));
        }
        catch (e) {
        }
        i++;
        if (!filename.includes("sys_hub_action_type_definition"))
            otherFiles[filename] = "";
        if (filename.includes("sys_hub_action_type_definition"))
            typeDefFiles[filename] = "";
        else if (filename.includes("sys_complex"))
            coFiles[filename] = "";
        else if (filename.includes("sys_hub_flow"))
            flowFiles[filename] = "";

        file.on('data', function (data) {
            if (!filename.includes("sys_hub_action_type_definition"))
                otherFiles[filename] += data
            if (filename.includes("sys_complex"))
                coFiles[filename] += data
            else if (filename.includes("sys_hub_action_type_definition"))
                typeDefFiles[filename] += data;
            else if (filename.includes("sys_hub_flow"))
                flowFiles[filename] += data;
        });
        file.on('end', function () {
        });
    });
    busboy.on('finish', function () {
        global.folderRoot = filePaths[0].split('/')[0];
        try {
            xmlParser.parseString(typeDefFiles[0], function (err, result) {
                if (result) {
                    global.spokeName = result.record_update.sys_hub_action_type_definition[0].sys_package[0].$.display_value.replace("Spoke", "").trim();
                    module.exports.spoke_name = result.record_update.sys_hub_action_type_definition[0].sys_package[0].$.display_value.replace("Spoke", "").trim();
                }
            });
        }
        catch (e) {
            console.log('Cannot read spoke name ' + e.message);
        }
        res.redirect('../purpose');
    });
    req.pipe(busboy);
}

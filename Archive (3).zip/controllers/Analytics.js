const fs = require("fs");
const path = require("path");
export const renderAnalytics = (req,res) => {
    const usageFile = JSON.parse(fs.readFileSync(path.join(__dirname,'../usage-statistics.json')));
    var toolStats = usageFile["Tool Stats"];
    var spokeStats = usageFile['Spoke Details'];
    var desc_tool_hits,co_tool_hits,dc_tool_hits,pc_tool_hits;
    for (var i =0 ;i<toolStats.length;i++)
    {
        if(toolStats[i]["Tool Name"] == "Description Tool")
        {
            desc_tool_hits = toolStats[i].Hits;
        } 
        if(toolStats[i]["Tool Name"] == "Clean Up Tool")
        {
            co_tool_hits = toolStats[i].Hits;
        } 
        if(toolStats[i]["Tool Name"] == "Dynamic Choice Remover Tool")
        {
            dc_tool_hits = toolStats[i].Hits;
        } 
        if(toolStats[i]["Tool Name"] == "Plugin Converter Tool")
        {
            pc_tool_hits = toolStats[i].Hits;
        } 
    }
    var total_spokes = spokeStats.length;
    res.render("analytics-dashboard",{"desc_tool_hits":desc_tool_hits,"co_tool_hits":co_tool_hits,"dc_tool_hits":dc_tool_hits,"pc_tool_hits":pc_tool_hits,"total_spokes":total_spokes});

}

export const renderSpokes = (req,res) =>
{
    const usageFile = JSON.parse(fs.readFileSync(path.join(__dirname,'../usage-statistics.json')));
    var spokeStats = usageFile['Spoke Details'];
    var spokesList =[];
    for(var i=0; i<spokeStats.length;i++)
    {
    spokesList.push(spokeStats[i]["Spoke Name"]);
    }
    res.render("spokes-served",{"spokesList":spokesList});
}
//Utils for the description tool

export const getCoFileFromId = (coId, coMap) => {
    coId = coId.substring(coId.indexOf(":") + 1);
    var ids = Object.keys(coMap);
    for (var i in ids) {
        if (ids[i] == coId)
            return coMap[ids[i]];
    }
}

export const checkAndMap = (complexObjectId, coMap, json) => {
    //console.log('coID ' + complexObjectId);
    complexObjectId = complexObjectId.substring(complexObjectId.indexOf(":") + 1);
    var complexObjectIds = Object.keys(coMap);
    for (var i in complexObjectIds) {
        if (complexObjectIds[i] == complexObjectId)
            coMap[complexObjectIds[i]] = json;
    }
    return coMap;
}

export const xmlGenerator = (req, res, app) => {
    console.log(req.body.button);
    if(req.body.button == "Show List")
    {
        res.render('showActions', {files: global.actionMap, action_details : global.actionDetails});
    }
    else{
    var xml2js = require('xml2js');
    var fs = require("fs");
    var descHtml = '';
    var outputs = [];
    var inputs = [];
    var error_messages = [];
    var i = 0;
    if(req.body.button == "Next Action")
    {
        var nextAction = actionList[actionList.indexOf(currentAction)+1];
        if(nextAction)
        {
        nextAction.replace(' ','+');
        res.redirect('/submit?actionName='+nextAction);
        }
        else
        res.redirect('/pickTool');
    }
    console.log(JSON.stringify(req.body));
    while (true) {
        var input = {};
        if (!req.body[i + '_input_name'])
            break;
        input.label = req.body[i + '_input_name'];
        if (req.body.button == "Apply Best Practices")
            input.value = validateInput(req.body[i + '_input_value'], "input");
        else
            input.value = req.body[i + '_input_value'];
        inputs.push(input);
        i++;
    }
    i = 0;
    while (true) {
        var output = {};
        if (!req.body[i + '_output_name'])
            break;
        output.label = req.body[i + '_output_name'];
        if (req.body.button == "Apply Best Practices")
            output.value = validateInput(req.body[i + '_output_value'], "output");
        else
            output.value = req.body[i + '_output_value'];
        outputs.push(output);
        i++;
    }
    i = 0;
    while (true) {
        var output = {};
        if (!req.body["em_" + i])
            break;
        if (req.body.button == "Apply Best Practices")
            error_messages.push(validateInput(req.body["em_" + i], "error_message"));
        else
            error_messages.push(req.body["em_" + i])
        i++;
    }
    var description = validateInput(req.body['description'], "description");
    if (req.body.button == "Apply Best Practices")
        res.render('mainpage', { inputs: inputs, outputs: outputs, error_messages: error_messages, actionName: global.actionName, description: description });
    else {
        descHtml = '<p id = "short_desc"> ' + req.body['description'] + '</p><p><b>Inputs</b> :</p> <ul id = "inputs">';
        for (var i = 0; i < inputs.length; i++) {
            descHtml += "<li><b>" + inputs[i].label + "</b> - " + inputs[i].value + "</li>";
        }
        descHtml += "<p></p>";
        descHtml += "</ul> <p><b>Outputs</b> : </p><ul id ='outputs'>";
        for (var i = 0; i < outputs.length; i++) {
            descHtml += "<li><b>" + outputs[i].label + "</b> - " + outputs[i].value + "</li>";
        }
        descHtml += "</ul><p></p>";
        descHtml += "<p><b>Error Messages</b> : </p><ul id = 'error_messages'>";
        for (var i = 0; i < error_messages.length; i++) {
            descHtml += "<li>" + error_messages[i] + "</li>";
        }
        descHtml += "</ul><p></p>";
        descHtml += "<p>To use this action, the corresponding " + global.spokeName + " connection and credential must be created and associated with the " + global.spokeName + " Connection & Credential alias. <a target='_blank' href='http://docs.servicenow.com/?context=CSHelp:credentials-connections-alias'>Learn More</a></p>  <p></p> <p><b>Note</b>: Requires a subscription for production use. <a target='_blank' href='https://docs.servicenow.com/?context=CSHelp:IntegrationHub-licensing-information'>Read More</a>.</p>";
        descHtml += "<!-- This description is generated using the description tool -->";
        if (global.jsonFile) {
            global.jsonFile.record_update.sys_hub_action_type_definition[0].description[0] = descHtml;
            var builder = new xml2js.Builder();
            var xml = builder.buildObject(global.jsonFile);
            var writeStream = fs.createWriteStream("./files/" + global.fileName);
            var action_name = global.actionName.substring(global.actionName.indexOf(':')+2);
            console.log('ac name is '+JSON.stringify(global.actionDetails));
            writeStream.write(xml, (err) => {
                if (err) {

                }
                else {
                    res.download("./files/" + global.fileName, global.fileName, function (err) {
                        //console.log('download callback called');
                        if (err) {
                            //console.log('something went wrong');
                        }
                        else
                        {

                            for(var i=0;i<actionDetails.length;i++)
                            {
                                if(actionDetails[i].name == action_name)
                                {
                                actionDetails[i].status = true;
                                break;
                                }
                            }
                            actionDetails.status = true;
                            fs.unlink("./files/" + global.fileName, function (err) { });
                        }
                    });
                }
            });
            writeStream.end();
        }
    }
}
}

export const recommendFieldValue = (label, type) => {
    if (label) {
        if (label == "Status" && type == 'output')
            return 'If the request is executed successfully, Status is set to “Success”. If there is a failure in ' + global.spokeName + ', Status is set to “Error”.';
        if (label == "Error Message")
            return 'Reason for error. Populated only when an error occurs.';
        if (label == "Additional Fields")
            return 'Additional fields or values you wish to add to the details.';

        if (label.toString().includes("ID") && !label.toString().includes("IID")) {
            var label_without_id = label.toString().replace(" ID", "");
            return 'Unique ID of the ' + label_without_id + ".";
        }
        return "";
    }
    else
        return "";
}

export const generateErrorMessageOnInput = (errorMessages, label, type) => {
    if (label.toString().includes("ID")) {
        var label_without_id = label.toString().replace(" ID", "");
        errorMessages.push("Invalid " + label_without_id + ".");
    }
}

export const validateInput = (value, type) => {
    if (!value.includes("List of objects") && !value.includes("object containing")) {
        value = value.trim().charAt(0).toUpperCase() + value.trim().slice(1);
        if (type == "input") {
            value = value.toString().toLowerCase();
            value = value.trim().charAt(0).toUpperCase() + value.trim().slice(1);
        }
        if (value.toString().trim().substring(0, 3) == "Id ")
            value = replace(value, "Id ", "ID ");
        value = replace(value, " id", " ID");
        value = replace(value, " Id", " ID");
        if (value.toString().charAt(value.toString().length - 1) != '.' && value.toString().trim() != "")
            value = value + ".";
        if (value.toString().toLowerCase().trim().substring(0, 6) == "the id") {
            value = value.replace("The ID", "Unique ID");
            value = value.replace("the ID", "Unique ID");
            value = value.trim().charAt(0).toUpperCase() + value.trim().slice(1);
        }
        if (value.toString().toLowerCase().trim().substring(0, 2) == "id") {
            value = value.replace("ID", "Unique ID");
            value = value.trim().charAt(0).toUpperCase() + value.trim().slice(1);
        }

        if (value.toString().toLowerCase().trim().substring(0, 3) == "the") {
            value = value.replace("The", "");
            value = value.trim().charAt(0).toUpperCase() + value.trim().slice(1);
        }
        value = replace(value, "e.g", "for example");
        value = replace(value, "e.t.c.", "and so on.");
        value = replace(value, "e.t.c", "and so on");
        value = replace(value, "does not", "doesn't");
        value = replace(value, "should not", "shouldn't");
        value = replace(value, "can not", "can't");
        value = replace(value, "could not", "couldn't");
        value = replace(value, "should not", "shouldn't");
        value = replace(value, "have not", "haven't");
        value = replace(value, "need not", "needn't");
        value = replace(value, "wish", "want");
        value = replace(value, "adds", "haven't");
        value = replace(value, "need not", "needn't");
        value = replace(value, "wish", "want");
        value = replace(value, "true", "True");
        value = replace(value, "false", "False");
        value = replace(value, "Please ", "");
        value = replace(value, "please ", "");
        if (type == "description") {
            if (value.toString().trim() != "") {
                value = replace(value, "this action", "");
                value = replace(value, "This action", "");
                var firstWord = value.toString().trim().split(" ")[0];
                if (firstWord.charAt(firstWord.length - 1) != 's' && firstWord.charAt(firstWord.length - 1) != '.')
                    value = replace(value, firstWord, firstWord + "s");
            }
            value = value.trim().charAt(0).toUpperCase() + value.trim().slice(1);
        }

        if (type == "error_message") {
            if (value.toString().toLowerCase().includes("is invalid.")) {
                var words = value.toString().trim().split(" ");
                var mainIndex;
                for (var i = 0; i < words.length; i++) {
                    if (words[i].toLowerCase() == "is" && words[i + 1].toLowerCase() == "invalid.") {
                        mainIndex = i - 1;
                    }
                }
                value = "Invalid " + words[mainIndex] + ".";
            }
            if (value.toString().toLowerCase().includes("is invalid or missing.")) {
                var words = value.toString().trim().split(" ");
                var mainIndex;
                for (var i = 0; i < words.length; i++) {
                    if (words[i].toLowerCase() == "is" && words[i + 1].toLowerCase() == "invalid") {
                        mainIndex = i - 1;
                    }
                }
                value = "Invalid or missing " + words[mainIndex] + ".";
            }
        }
        value = sentenceCase(value, false);
        return value;
    }
    value = sentenceCase(value, false);
    return value;
}
export const sentenceCase = (input, lowercaseBefore) => {
    console.log('input is ' + input);
    input = (input === undefined || input === null) ? '' : input;
    if (lowercaseBefore) { input = input.toLowerCase(); }
    return input.toString().replace(/(^|\. *)([a-z])/g, function (match, separator, char) {
        return separator + char.toUpperCase();
    });
}

export const replace = (value, pre, post) => {
    if (value.toString().toLowerCase().includes(pre.toLowerCase())) {
        value = value.replace(pre, post);
    }
    return value;
}

export const successHandler = (req, res) => {
    res.sendStatus(200);
}

export const getCoValue = (name, coID, attribute, label, file) => {
    var structure_json = {};
    global.rootKey = Object.keys(file)[0];
    if (attribute == "object")
        global.mainRoot = file[Object.keys(file)[0]];
    else
        if (attribute == "array.object") {
            var nRoot = global.mainRoot = file[Object.keys(file)[0]];
            if (nRoot) {
                var nKeys = Object.keys(nRoot);
                global.mainRoot = nRoot[nKeys[0]][0];
            }
            else
                return "";
        }
    createStructure(global.mainRoot, Object.keys(file)[0], structure_json, file);
    finalizeStructure(structure_json);
    var keys1 = Object.keys(structure_json);
    var mainKey;

    for (var i in keys1) {
        if (keys1[i].toString().includes("FlowDesigner")) {
            mainKey = keys1[i];
            break;
        }
    }

    if (attribute == "array.object")
        var desc = "";
    else
        var desc = "Complex object containing these fields: - <ul>"
    return generateDescriptionFromObject(structure_json[mainKey], desc);
}

export const getLabelFromName = (name, root) => { // give the name of the object and the nearest root to it
    if (root[name + ".$field_facets"]) {
        var smf = root[name + ".$field_facets"].SimpleMapFacet;
        smf = JSON.parse(smf);
        return smf.label;
    }
    else
        return "";
}

export const createStructure = (root, parent, structure_json, file) => {
    var keys = Object.keys(root);
    for (var i in keys) {
        if (!keys[i].toString().includes("$field_facets") && keys[i] != "SimpleMapFacet") {
            if (typeof root[keys[i]] == "string") {
                if (!structure_json[parent]) {
                    structure_json[parent] = [];
                    structure_json[parent].push(getLabelFromName(keys[i], root));
                }
                else
                    structure_json[parent].push(getLabelFromName(keys[i], root));
            }
            if (typeof root[keys[i]] != "string") {
                createStructure(root[keys[i]], keys[i], structure_json);
            }
        }
    }
    return;
}

export const getParentElement = (ele, root, diction, parent, structure_json) => {

    if (Array.isArray(root))
        root = root[0];
    var keys = Object.keys(root);
    for (var i in keys) {
        if (keys[i] == ele) {
            diction.object = root;
            diction.root = parent;
            diction.found = true;
            return diction;
        }
        if (typeof root[keys[i]] != "string") {

            var output = getParentElement(ele, root[keys[i]], diction, keys[i], structure_json);
            if (output.found)
                return diction;
        }
    }
    return diction;
}

export const finalizeStructure = (structure_json) => {
    var keys = Object.keys(global.mainRoot);
    var structKeys = Object.keys(structure_json);
    for (var i in structKeys) {
        var diction = {
            root: null,
            found: false,
            object: null
        };
        var parent = getParentElement(structKeys[i], global.mainRoot, diction, global.rootKey, structure_json).root;
        var parentObject = getParentElement(structKeys[i], global.mainRoot, diction, global.rootKey, structure_json).object;
        if (parent != null) {
            if (structure_json[parent]) {
                if (!checkIfExist(structure_json[parent], structure_json[structKeys[i]])) {
                    if (getLabelFromName(structKeys[i], parentObject) != null && getLabelFromName(structKeys[i], parentObject) != "")
                        structure_json[parent].push(getLabelFromName(structKeys[i], parentObject));
                    structure_json[parent].push(structure_json[structKeys[i]]);
                }
            }
            else {
                structure_json[parent] = [];
                if (getLabelFromName(structKeys[i], parentObject) != null && getLabelFromName(structKeys[i], parentObject) != "")
                    structure_json[parent].push(getLabelFromName(structKeys[i], parentObject));
                structure_json[parent].push(structure_json[structKeys[i]]);
                finalizeStructure(structure_json);
            }
        }
    }
}

export const checkIfExist = (arr, ele) => {
    for (var i in arr) {
        if (arr[i] == ele)
            return true;
    }
    return false;
}

export const generateDescriptionFromObject = (obj, desc) => {
    if (obj[0] == "") {
        desc += "</ul>";
        return desc;
    }
    if (Array.isArray(obj[0])) {
        if (desc != "") {
            desc = desc.substring(0, desc.length - 5);
            desc += " - List of objects containing these values";
        }
        else {
            desc += "List of objects containing these values";
        }
        desc += "<ul>";
        obj = obj[0];
    }
    console.log("ob " + JSON.stringify(obj));
    var keys = Object.keys(obj);
    for (var j = 0; j < keys.length; j++) {
        if (Array.isArray(obj[j + 1])) {
            desc += "<li> " + obj[j] + "<ul>";
            desc = generateDescriptionFromObject(obj[j + 1], desc);
            desc += "</li>";
            j = j + 1;
        }
        else {
            desc += "<li> " + obj[j] + " </li>";
        }
    }
    desc += "</ul>";
    return desc;
}


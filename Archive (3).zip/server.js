var fs = require('fs');
const emailScheduler = require('./controllers/EmailModule');
const cron = require('node-schedule');
var express = require('express');
var cors = require('cors');
var hbs = require('express-handlebars');
var busboyBodyParser = require('busboy-body-parser');
var path = require('path');
const port = process.env.PORT || 8085;
var { routes } = require('./routes/myroutes');
var app = express();
app.set('views', path.join(__dirname, 'views'));
app.engine('handlebars', hbs());
app.set('view engine', 'handlebars');
app.use(express.static(__dirname + '/public'));
const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cors());
//app.use(busboyBodyParser());
var busboy = require('connect-busboy');
var view_path = __dirname + '/views/';
app.use(busboy());
app.use(express.static(path.join(__dirname, 'bower_components')));
routes(app);
var rule = new cron.RecurrenceRule();
rule.dayOfWeek = [5];
rule.hour = 11;
rule.minute = 30;
cron.scheduleJob(rule, function() {
    emailScheduler.sendEmail('karthik.veenam@servicenow.com,chakradhar.jn@servicenow.com,srikanth.challapilla@servicenow.com', 'Spoke Tools Weekly Stats', 'Hi, PFA for the weekly statistics of the Spoke Tools', path.join(__dirname, "/usage-statistics.json")); // write your logic here to send email
});
app.get('/', (request, response) => {
    response.sendFile(view_path + "homepage.html")
});
app.listen(port, () => {
    console.log("Server runnning");
});
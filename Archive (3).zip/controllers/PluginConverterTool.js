const fs = require('fs');
const fse = require('fs-extra'); // file system ops
const archiver = require('archiver')
const path = require('path');
const xml2js = require('xml2js');
const replace = require('replace');
const { addToToolStats } = require('./Commons');
const { AddToUsageStatistics } = require('./Commons');
const extractDir = path.join(__dirname, '../uploadDir/');
const templateDir = path.join(__dirname, '../public/Template/');
const outputDir = path.join(__dirname, '../public/Outputs/');

if (!fs.existsSync(extractDir)) {
    fs.mkdirSync(extractDir);
}

if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir);
}

const createzip = (filename, cz_callback) => {
    var response = {
        "success": "true"
    }
    var output = fs.createWriteStream(outputDir + filename + '.zip');
    var archive = archiver('zip');

    output.on('close', function() {
        console.log('archiver has been finalized and the output file descriptor has closed.');
        return cz_callback(response);
    });

    archive.on('error', function(err) {
        throw err;
    });

    archive.pipe(output);

    archive.directory(outputDir + '/Plugin/' + filename, filename);
    archive.finalize(function(err, bytes) {
        if (err) {
            throw err;
        }

        console.log(bytes + ' total bytes');
    });
}


const find_and_replace = (filePath, old_value, new_value, callback) => {
    var response = {
        "success": "true"
    }
    fs.readFile(filePath, 'utf8', function(err, data) {
        if (err) {
            return console.log(err);
        }
        //console.log(data);
        var regexold = new RegExp(old_value, "g");
        var result = data.replace(regexold, new_value);
        //console.log(result);
        fs.writeFile(filePath, result, 'utf8', function(err) {
            if (err) {
                return console.log(err);
            } else {
                return callback(response);
            }
        });
    });
}

const deleteFiles = (pattern, dirPath, callback) => {

    fs.readdirSync(dirPath)
        .filter(f => pattern.test(f))
        .map(f => fs.unlinkSync(dirPath + "/" + f))
        // get all file names in directory
        // fs.readdir(dirPath, (err, fileNames) => {
        //     if (err) throw err;
        //     // iterate through the found file names
        //     for (const name of fileNames) {
        //         // if file name matches the pattern
        //         if (pattern.test(name)) {
        //             // try to remove the file and log the result
        //             fs.unlink(path.resolve(dirPath + "/" + name), (err) => {
        //                 if (err) throw err;
        //                 console.log(`Deleted ${name}`);
        //                 callback('Deletion Success');
        //             });
        //         }
        //     }
        // });
}

function walkSync(currentDirPath, oldscopename, newscopename, pluginname, callback) {
    fs.readdirSync(currentDirPath).forEach(function(name) {
        var filePath = path.join(currentDirPath, name);
        var stat = fs.statSync(filePath);
        if (stat.isFile()) {
            if (name.match(/sys_app_[^_]*.xml/g)) {
                find_and_replace(processDir + '/plugin.xml', 'TEMPLATE_CONVERT_SYS_ID_TEMPLATE_CONVERT', (name.substring(8, name.length - 4)), (res) => {
                    if (res) {
                        console.log('Sys ID replaced in plugin.xml.');
                    }
                });
                fse.copy(filePath, processDir + "/scope/" + name, (err) => {
                    if (err) {
                        console.error(err);
                    }
                    console.log(filePath + " Copy Success!");
                    find_and_replace(processDir + "/scope/" + name, '<version>.*</version>', '<version>${project.version}</version>', (res) => {
                        if (res) {
                            console.log('Version replaced in ' + processDir + "/scope/" + name + '.xml.');
                            find_and_replace(processDir + "/scope/" + name, '<name>.*</name>', '<name>' + pluginname + '</name>', (res) => {
                                if (res) {
                                    console.log('Plugin Name replaced in ' + processDir + "/scope/" + name + '.xml.');
                                }
                            });
                        }
                    });
                });
            }
        } else if (stat.isDirectory()) {
            if (name == "update" || name == "dictionary") {
                fse.copy(filePath, processDir + "/" + name, (err) => {
                    if (err) {
                        console.error(err);
                    } else {
                        console.log(filePath + " Copy Success!");
                        if (oldscopename) {
                            const files = fs.readdirSync(processDir + "/" + name);
                            const match = RegExp(oldscopename, 'g');
                            files
                                .filter(file => file.match(match))
                                .forEach(file => {
                                    const oldFilenamePath = path.join(processDir + "/" + name, file);
                                    const newFilenamePath = path.join(processDir + "/" + name, file.replace(match, newscopename));

                                    fs.renameSync(oldFilenamePath, newFilenamePath);
                                    console.log(oldFilenamePath + " renamed to " + newFilenamePath);
                                });
                        }
                        deleteFiles(/^(sys_db_).*.xml/, processDir + "/" + name, (err) => {
                            if (!err) {
                                console.log("Deletion of sys_db_* files successful.");
                            } else {
                                console.error(err);
                            }
                        })
                        deleteFiles(/^(ua_table_licensing_config_).*.xml/, processDir + "/" + name, (err) => {
                            if (!err) {
                                console.log("Deletion of ua_table_licensing_config_* files successful.");
                            } else {
                                console.error(err);
                            }
                        })
                        deleteFiles(/^(sys_index_).*.xml/, processDir + "/" + name, (err) => {
                            if (!err) {
                                console.log("Deletion of sys_index_* files successful.");
                            } else {
                                console.error(err);
                            }
                        })
                        deleteFiles(/^(sys_dictionary_).*.xml/, processDir + "/" + name, (err) => {
                            if (!err) {
                                console.log("Deletion of sys_dictionary_* files successful.");
                            } else {
                                console.error(err);
                            }
                        })
                        deleteFiles(/^sys_documentation_((?!var__m_connection_attributes_|var__m_sys_hub_flow_input_|var__m_sys_hub_flow_output_).)*.xml/, processDir + "/" + name, (err) => {
                            if (!err) {
                                console.log("Deletion of sys_documentation_*  files with few exceptions successful.");
                            } else {
                                console.error(err);
                            }
                        })
                    }
                    if (name == "update")
                        callback("Task Completed With All iteration");
                });
            }
            walkSync(filePath, oldscopename, newscopename, pluginname, callback);
        }
    });
}

export const pluginConverterToolEntry = (req, resp) => {
    var spoke_name;
    try {
        xml2js.parseString(global.typeDefFiles[Object.keys(global.typeDefFiles)[0]], function(err, result) {
            if (result) {
                spoke_name = result.record_update.sys_hub_action_type_definition[0].sys_package[0].$.display_value.replace("Spoke", "").trim();
                addToToolStats("Plugin Converter Tool");
                AddToUsageStatistics(spoke_name, "Plugin Converter Tool");
            } else {
                console.log('err ' + err);
            }
        });
    } catch (e) {
        console.log('Cannot read spoke name ' + e.message);
    }
    global.processDir = path.join(__dirname, '../public/Outputs/Plugin/' + req.body.artifact_id + '/src/main/plugins/com.$SCOPE_NAME_REPLACED_WITH_PERIOD$');
    fse.copy(templateDir, outputDir + "/Plugin/" + req.body.artifact_id, (err) => {
        if (err) {
            console.error(err);
        } else {
            console.log(templateDir + " Copy Success!");
            walkSync(extractDir, req.body.old_scope_name, req.body.scope_name, req.body.plugin_name, function(status) {
                console.log(status);
                replace({
                    regex: /<sys_updated_by>.*<\/sys_updated_by>/g,
                    replacement: '<sys_updated_by>admin</sys_updated_by>',
                    paths: [processDir],
                    recursive: true,
                    silent: true,
                });
                replace({
                    regex: /<sys_created_by>.*<\/sys_created_by>/g,
                    replacement: '<sys_created_by>admin</sys_created_by>',
                    paths: [processDir],
                    recursive: true,
                    silent: true,
                });
                if (req.body.old_scope_name) {
                    var re = new RegExp(req.body.old_scope_name, "g");
                    replace({
                        regex: re,
                        replacement: req.body.scope_name,
                        paths: [processDir],
                        recursive: true,
                        silent: true,
                    });
                }
                find_and_replace(processDir + '/plugin.xml', 'TEMPLATE_CONVERT_DESCRIPTION_TEMPLATE_CONVERT', req.body.description, (res) => {
                    if (res) {
                        console.log('Description replaced in plugin.xml.');
                        find_and_replace(processDir + '/plugin.xml', 'TEMPLATE_CONVERT_SCOPE_NAME_TEMPLATE_CONVERT', req.body.scope_name, (res) => {
                            if (res) {
                                console.log('Sys ID replaced in plugin.xml.');
                                find_and_replace(outputDir + "/Plugin/" + req.body.artifact_id + '/pom.xml', "TEMPLATE_CONVERT_ARTIFACTID_TEMPLATE_CONVERT", req.body.artifact_id, (res) => {
                                    if (res) {
                                        console.log('Artifact IDs replaced.');
                                        find_and_replace(outputDir + "/Plugin/" + req.body.artifact_id + '/pom.xml', "TEMPLATE_CONVERT_GIT_URL_TEMPLATE_CONVERT", req.body.git_repo, (res) => {
                                            if (res) {
                                                console.log('GIT Repo replaced.');
                                                find_and_replace(processDir + '/plugin.xml', 'TEMPLATE_CONVERT_PLUGIN_NAME_TEMPLATE_CONVERT', req.body.plugin_name, (res) => {
                                                    if (res) {
                                                        console.log('Plugin Name replaced.');
                                                        find_and_replace(outputDir + "/Plugin/" + req.body.artifact_id + '/pom.xml', "TEMPLATE_CONVERT_SCOPE_NAME_REPLACED_WITH_PERIOD_TEMPLATE_CONVERT", (req.body.scope_name.replace(/_/g, '.')), (res) => {
                                                            if (res) {
                                                                console.log('Scope replaced with periods in pom.xml');
                                                                find_and_replace(processDir + '/plugin.xml', 'TEMPLATE_CONVERT_SCOPE_NAME_REPLACED_WITH_PERIOD_TEMPLATE_CONVERT', (req.body.scope_name.replace(/_/g, '.')), (res) => {
                                                                    if (res) {
                                                                        console.log('Scope replaced with periods in plugin.xml');
                                                                        fs.rename(processDir, outputDir + '/Plugin/' + req.body.artifact_id + '/src/main/plugins/com.' + (req.body.scope_name.replace(/_/g, '.')), function(err) {
                                                                            if (err) throw err;
                                                                            console.log('Template folder rename complete');
                                                                            createzip(req.body.artifact_id, (res) => {
                                                                                if (res) {
                                                                                    resp.download(outputDir + req.body.artifact_id + '.zip', req.param('file'), function(err) {
                                                                                        fs.unlinkSync(outputDir + req.body.artifact_id + '.zip');
                                                                                        console.log(outputDir + req.body.artifact_id + '.zip' + ' File deleted.');
                                                                                        fse.removeSync(outputDir + '/Plugin/' + req.body.artifact_id);
                                                                                        console.log(outputDir + '/Plugin/' + req.body.artifact_id + ' Folder deleted.');
                                                                                        //fse.removeSync(extractDir + '/' + path.parse(req.file.originalname).name);
                                                                                        //console.log(extractDir + '/' + path.parse(req.file.originalname).name + ' Folder deleted.');
                                                                                    });
                                                                                }
                                                                            });
                                                                        });
                                                                    }
                                                                });
                                                            }
                                                        });
                                                    }
                                                });
                                            }
                                        });
                                    }
                                });
                            }
                        });
                    }
                });
            });
        }
    });
};
//Entry Point for the description tool
const { getCoFileFromId } = require('./SpokeDescriptionToolUtils');
const { checkAndMap } = require('./SpokeDescriptionToolUtils');
const { recommendFieldValue } = require('./SpokeDescriptionToolUtils');
const { generateErrorMessageOnInput } = require('./SpokeDescriptionToolUtils');
const { getCoValue } = require('./SpokeDescriptionToolUtils');
const { getAttributeFromAttrubutesString } = require('./Commons');
const { AddToUsageStatistics } = require('./Commons');
const { addToToolStats } = require('./Commons');
const { parse } = require('node-html-parser');
const himalaya = require('himalaya');
export const selectAction = (req, res) => {
    addToToolStats("Description Tool");
    var xmlParser = require('xml2js');
    global.actionDetails = [];
    var actionTypes = [];
    for (var i in typeDefFiles) {
        xmlParser.parseString(typeDefFiles[i], function (err, result) {
            if (result) {
                if (result.record_update && result.record_update.sys_hub_action_type_definition && result.record_update.sys_hub_action_type_definition[0].name[0]) {
                    actionMap[result.record_update.sys_hub_action_type_definition[0].name[0]] = result;
                    actionTypes.push(result.record_update.sys_hub_action_type_definition[0].action_template[0])
                }
            }
        });

    }
    global.actionList = Object.keys(actionMap);
    for (var i in global.actionList) {
        var action = {};
        action.name = global.actionList[i];
        action.status = false;
        if (actionTypes[i] == "DATASTREAM")
            action.datastream = true;
        else
            action.datastream = false;
        actionDetails.push(action);
    }
   // console.log('actions aare ' + JSON.stringify(actionTypes));
  //  console.log('actions aare ' + JSON.stringify(actionDetails));
    if (req.body.purpose == 'wd')
        res.render('showActions', { files: actionMap, action_details: actionDetails });
}

export const descriptionToolEntry = (req, res, actionName) => {
    var xmlData = {};
    console.log('actionName' + actionName)
    global.currentAction = actionName;
    xmlData = global.actionMap[actionName];
    var errorMessages = [];
    var xmlParser = require('xml2js');
    var Busboy = require('busboy');
    var ins = [];
    var outs = [];
    var coMap = {};
    var result = xmlData;
    var err = "";
    global.jsonFile = result;
    errorMessages.push("Invalid Credentials.");

    if (!err && result.record_update && result.record_update.sys_hub_action_output) {
        global.spokeName = result.record_update.sys_hub_action_type_definition[0].sys_package[0].$.display_value.replace("Spoke", "").trim();
        AddToUsageStatistics(global.spokeName, "Description Tool");
        global.descriptionJSON = {};
        global.description = unescape(result.record_update.sys_hub_action_type_definition[0].description[0]);
        if (global.description.includes("This description is generated using the description tool")) {
            var descWithoutBold = description.replace(/<b>/g, "").replace(new RegExp("</b>", 'g'), "");
            global.descriptionJSON = { shortdesc: "", inputs: {}, outputs: {}, errorMessages: [] };
            const root = parse(descWithoutBold);
            if(root.querySelector('#short_desc'))
            var short_desc = himalaya.parse(root.querySelector('#short_desc').toString());
         //   console.log('short_desc '+ JSON.stringify(short_desc));
            descriptionJSON.shortdesc = short_desc[0].children[0].content;
            var htmlJson = himalaya.parse(root.querySelector('#inputs').toString());
            var eMessages = himalaya.parse(root.querySelector('#error_messages').toString());
            for (var i = 0; i < eMessages[0].children.length; i++) {
                if (eMessages[0].children[i].tagName == "li") {
                    descriptionJSON.errorMessages.push(eMessages[0].children[i].children[0].content);
                }
            }

            for (var i = 0; i < htmlJson[0].children.length; i++) {
                if (htmlJson[0].children[i].tagName == "li") {
                    var cont = htmlJson[0].children[i].children[0].content;
                    var label = cont.split(" - ")[0];
                    var value = cont.split(" - ")[1];
                    descriptionJSON.inputs[label] = value;
                }
            }
            var htmlJsonOutputs = himalaya.parse(root.querySelector('#outputs').toString());
            for (var i = 0; i < htmlJsonOutputs[0].children.length; i++) {
                if (htmlJsonOutputs[0].children[i].tagName == "li") {
                    var cont = htmlJsonOutputs[0].children[i].children[0].content;
                    var label = cont.split(" - ")[0];
                    var value = cont.split(" - ")[1];
                    descriptionJSON.outputs[label] = value;
                }
            }

        }
        //console.log(JSON.stringify(descriptionJSON));
        global.actionName = global.spokeName + " : " + result.record_update.sys_hub_action_type_definition[0].name;
        if (result.record_update.sys_hub_action_type_definition[0].action_template[0] == "DATASTREAM")
            global.actionType = "ds";
        else
            global.actionType = "action";
        global.fileName = "sys_hub_action_type_definition_" + result.record_update.sys_hub_action_type_definition[0].sys_id[0] + ".xml";
        if (result.record_update.sys_hub_action_input) {
            for (var i = 1; i < result.record_update.sys_hub_action_input.length; i++) {
                if (!result.record_update.sys_hub_action_input[i].label)
                    break;
                var input = {};
                input.label = result.record_update.sys_hub_action_input[i].label;
            //    console.log('label is ' + input.label);
                input.order = result.record_update.sys_hub_action_input[i].order[0];
                input.mandatory = result.record_update.sys_hub_action_input[i].mandatory[0];
                var attributes = result.record_update.sys_hub_action_input[i].attributes;
                input.attribute = getAttributeFromAttrubutesString(attributes, "uiType");
                var valueExists = getValueFromLabel(input.label, "inputs");
                    if (input.attribute == "object" || input.attribute == "array.object") {
                        input.coID = getAttributeFromAttrubutesString(attributes, "co_type_name");
                        coMap[input.coID] = "";
                    }
                    else if (valueExists != "")
                    input.value = valueExists;
                    else
                    input.value = recommendFieldValue(input.label, 'input');

                generateErrorMessageOnInput(errorMessages, input.label);
                ins.push(input);
            }
        }
        for (var i = 1; i < result.record_update.sys_hub_action_output.length; i++) {
            if (!result.record_update.sys_hub_action_output[i].label)
                break;
            var output = {};
            output.order = result.record_update.sys_hub_action_output[i].order[0];
            output.label = result.record_update.sys_hub_action_output[i].label;
            output.name = result.record_update.sys_hub_action_output[i].element;
            var attributes = result.record_update.sys_hub_action_output[i].attributes;
            output.attribute = getAttributeFromAttrubutesString(attributes, "uiType");
            var valueExists = getValueFromLabel(output.label, "outputs");

                if (output.attribute == "object" || output.attribute == "array.object") {
                    output.coID = getAttributeFromAttrubutesString(attributes, "co_type_name");
                    //console.log('co id is ' + output.coID);
                    coMap[output.coID] = "";
                }
                else if (valueExists != "")
                output.value = valueExists;
                else
                    output.value = recommendFieldValue(output.label, "output");

            if (global.actionType == "ds") {
                if (output.attribute == "object")
                    outs.push(output);
            }
            else
                outs.push(output);
        }
        //console.log("coMap is " + JSON.stringify(coMap));
        if(descriptionJSON.errorMessages && descriptionJSON.errorMessages.length!=0)
        errorMessages = descriptionJSON.errorMessages;
        var short_description = descriptionJSON.shortdesc;
        console.log('dad '+JSON.stringify(descriptionJSON));
        ins.sort((a, b) => a.order - b.order);
        outs.sort((a, b) => a.order - b.order);
        res.render('mainpage', { description: short_description,inputs: ins, outputs: outs, error_messages: errorMessages, actionName: global.actionName });
    }
    else {
        res.send(JSON.stringify(result));
    }
    var coKeys = Object.keys(global.coFiles);
    //console.log('lenght is ' + JSON.stringify(coKeys));
    //console.log('co file is ' + global.coFiles[coKeys[2]]);
    for (var i = 0; i < coKeys.length; i++) {
        try {
            xmlParser.parseString(global.coFiles[coKeys[i]], function (err, result) {
                if (result) {
                    if (result.record_update && result.record_update.sys_complex_object) {
                        var contentString = result.record_update.sys_complex_object[0].serialized_content;
                        var unEscaped = unescape(unescape(unescape(contentString)));
                        var json = JSON.parse(unEscaped);
                        var complexObjectId = Object.keys(json)[0];
                        coMap = checkAndMap(complexObjectId, coMap, json);
                    }
                }
                else {
                }
            });
        }
        catch (e) {
        }
    }
    //console.log(JSON.stringify(coMap));
    for (var i in ins) {
        if (ins[i].attribute == "object" || ins[i].attribute == "array.object") {
            var file = getCoFileFromId(ins[i].coID, coMap);
            try {
                ins[i].value = getCoValue(ins[i].name, ins[i].coID, ins[i].attribute, ins[i].label, file);
            }
            catch (e) {
                ins[i].value = "";
            }
        }

    }
    for (var i in outs) {
        if (outs[i].attribute == "object" || outs[i].attribute == "array.object") {
            var file = getCoFileFromId(outs[i].coID, coMap);
            try {
                outs[i].value = getCoValue(outs[i].name, outs[i].coID, outs[i].attribute, outs[i].label, file);
            }
            catch (e) {
                outs[i].value = "";
            }
        }
    }

}

const getValueFromLabel = (label, type) => {
    if (Object.keys(global.descriptionJSON).length == 0)
        return "";
    var keys = Object.keys(global.descriptionJSON[type]);
    if(keys)
    {
    for (var i = 0; i<keys.length; i++) {
        if (keys[i] == label) {
       //     console.log("yesss" + descriptionJSON[type][keys[i]]);
            return descriptionJSON[type][keys[i]];
        }
    }
    }
    return "";
}
